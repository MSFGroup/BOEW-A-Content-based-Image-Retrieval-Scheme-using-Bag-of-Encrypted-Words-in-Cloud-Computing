clear all;
clc;
strPath = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\ExperimentData\EncImgs\';
data = load([strPath 'GlobalHistogramHSVRound.mat']);
data000 = load([strPath 'GlobalHistogramHSVRoundJPEG.mat']);

picH = 1600;
picW = 600;
fsize = 12;

histograms = data.Histograms;
histograms000 = data000.Histograms;

H = [histograms000;histograms];%(:,1:101);
%H = H(:,1:101);
T = H'/3;
T(find(T==0)) = T(find(T==0)) + 0.000000000000000000000001;
Entrop =  -sum(T.*log2(T));


%figures; 
num = [0,1,5,10,20,50,100,500];
for i = [1,2,3,4,5,6,7,8]
    ax = subplot(8,1,i);
    %figures = figure('Position',[100,100,picW,picH]);
    figure = bar(ax,H(i,:));
    %axes1 = axes('FontSize',fsize,'Parent',figure);
    %xlabel(ax,'Value in H component');
    xlim([0 303])
    ylim([0 0.1])
    ylabel(ax,'Ratio','FontSize',8);
     title(['{\it N_{pmt}}=' int2str(num(i))],'FontSize',8);
    box(ax,'on');
    grid(ax,'on');
    hold(ax,'all');   
end
xlabel(ax,'Values in HSV components','FontSize',8);
% ax = subplot(3,1,2);
% %figures = figure('Position',[100,100,picW,picH]);
% figure = bar(ax,S);
% %axes1 = axes('FontSize',fsize,'Parent',figure);
% xlabel(ax,'Value in S component');
% xlim([1 101])
% ylabel(ax,'Ratio');
%  %title('{\it Q}=1','FontSize',12);
% box(ax,'on');
% grid(ax,'on');
% hold(ax,'all'); 
% ax = subplot(3,1,3);
% %figures = figure('Position',[100,100,picW,picH]);
% figure = bar(ax,V);
% %axes1 = axes('FontSize',fsize,'Parent',figure);
% xlabel(ax,'Value in V component');
% xlim([1 101])
% ylabel(ax,'Ratio');
%  %title('{\it Q}=1','FontSize',12);
% box(ax,'on');
% grid(ax,'on');
% hold(ax,'all'); 
saveas(figure,[strPath 'HistOneImg.eps'],'epsc2');







