
function [C,runningtime] = BOEWFunc_GenClusterCenter(localHistograms,clusterNum,maxIter,clusterDistanceType)
disp('In BOEWFunc_GenClusterCenter...');
tic
[~,C,~,~] = kmeans(localHistograms,clusterNum,'distance',clusterDistanceType,'MaxIter',maxIter,'display','final');
runningtime = toc
disp('In BOEWFunc_GenClusterCenter...');
end
