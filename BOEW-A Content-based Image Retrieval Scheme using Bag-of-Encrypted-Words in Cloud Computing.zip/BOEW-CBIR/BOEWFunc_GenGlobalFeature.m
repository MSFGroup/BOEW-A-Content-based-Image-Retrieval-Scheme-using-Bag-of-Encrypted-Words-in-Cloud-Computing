function globalFeatures = BOEWFunc_GenGlobalFeature(localHistograms,clusterCenters,clusterDistanceType)
    disp('In BOEWFunc_GenGlobalFeature...');
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% All the local histograms are stored in a cell
    imgNum          = size(localHistograms,1);%% it is 1491 for Inria
    featureLen      = size(clusterCenters,1);%% 
    globalFeatures  = zeros(imgNum,featureLen);
    tic;
    for imgIdx = 1:imgNum
        %%% For one image, computer the distance of each local histogram to each cluster center.
        similarDistances = pdist2(localHistograms{imgIdx},clusterCenters,clusterDistanceType);
        %%% Find the index of smallest elements in each row.    
        [~,idx]        = min(similarDistances,[],2);
        %%% The histogram of idx is the Global feature of the image
        bins                    = 0.5:1:featureLen+0.5;
        hist                     = histogram(idx,bins); 
        Features           =  hist.Values;
        Features            =Features/sum(Features);
        globalFeatures(imgIdx,:) = Features;    
    end
    toc

end


















