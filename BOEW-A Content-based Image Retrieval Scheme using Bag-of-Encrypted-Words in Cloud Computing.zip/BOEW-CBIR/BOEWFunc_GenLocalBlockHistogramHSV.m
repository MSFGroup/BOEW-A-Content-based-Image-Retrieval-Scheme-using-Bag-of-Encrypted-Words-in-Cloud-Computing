%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Written by Zhihua Xia, xia_zhihua@163.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [imgNames,localHistograms,runningTime] = BOEWFunc_GenLocalBlockHistogramHSV(strImgFolder,blockHight,blockWidth)
%imagefolder = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\';
disp('In BOEWFunc_GenLocalBlockHistogramHSV...');
dirOutput = dir(fullfile(strImgFolder,'*.png'));%*.png
imgNames={dirOutput.name};

imageNum = size(imgNames,2);
%imageNum = 1491;
localHistograms = cell(imageNum,1);%%%  imageNum
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
for imgIdx = 1:imageNum %%%  imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [H,S,V]=rgb2hsv(image);
    H = uint8(floor(H * 100));
    S = uint8(floor(S * 100));
    V = uint8(floor(V * 100));    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [imgHight,imgWidth] = size(H);
    step = 1;
    blkNumH     = floor(imgHight/blockHight);
    blkNumW    = floor(imgWidth/blockWidth);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    localHistofOneImg = zeros(floor(blkNumH/step) * floor(blkNumW/step), 303);
    
    blkIdx = 1;  
    %pack('tmp.mat');
    for blkIdxH = 1:step:blkNumH
        for blkIdxW = 1:step:blkNumW
                      
            localHistH = zeros(1,101);
            localHistS = zeros(1,101);
            localHistV = zeros(1,101);
            imgBlk_H = H(((blkIdxH-1)*blockHight+1):(blkIdxH*blockHight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth));
            imgBlk_S = S(((blkIdxH-1)*blockHight+1):(blkIdxH*blockHight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth));
            imgBlk_V = V(((blkIdxH-1)*blockHight+1):(blkIdxH*blockHight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth));
            
            for pixelIdx_H = 1:blockHight
                for pixelIdx_W = 1:blockWidth
                    localHistH(imgBlk_H(pixelIdx_H,pixelIdx_W) +1) = localHistH(imgBlk_H(pixelIdx_H,pixelIdx_W) +1) + 1;
                    localHistS(imgBlk_S(pixelIdx_H,pixelIdx_W) +1) = localHistS(imgBlk_S(pixelIdx_H,pixelIdx_W) +1) + 1;
                    localHistV(imgBlk_V(pixelIdx_H,pixelIdx_W) +1) = localHistV(imgBlk_V(pixelIdx_H,pixelIdx_W) +1) + 1;
                end
            end
            localHistofOneImg(blkIdx,:) = [localHistH localHistS localHistV];
            blkIdx = blkIdx +1;
            
        end
    end
    localHistograms{imgIdx} = localHistofOneImg;
     
end
runningTime = toc
disp('End of BOEWFunc_GenLocalBlockHistogramHSV.');
end



