%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Written by Zhihua Xia, xia_zhihua@163.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [imgNames,localHistograms,runningTime] = BOEWFunc_GenLocalBlockHistogramRGB(strImgFolder,blockHight,blockWidth)
%imagefolder = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\';
disp('In BOEWFunc_GenLocalBlockHistogramHSV...');
dirOutput = dir(fullfile(strImgFolder,'*.jpg'));
imgNames={dirOutput.name};

imageNum = size(imgNames,2);
%imageNum = 1491;
localHistograms = cell(imageNum,1);%%%  imageNum
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
for imgIdx = 1:imageNum %%%  imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
R = image(:,:,1);  
G = image(:,:,2);  
B = image(:,:,3);  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [imgHight,imgWidth,~] = size(image);
    step = 1;
    blkNumH     = floor(imgHight/blockHight);
    blkNumW    = floor(imgWidth/blockWidth);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    localHistofOneImg = zeros(floor(blkNumH/step) * floor(blkNumW/step), 768);
    
    blkIdx = 1;  
    %pack('tmp.mat');
    for blkIdxH = 1:step:blkNumH
        for blkIdxW = 1:step:blkNumW
                      
            localHistR = zeros(1,256);
            localHistG = zeros(1,256);
            localHistB = zeros(1,256);
            imgBlk_R = R(((blkIdxH-1)*blockHight+1):(blkIdxH*blockHight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth));
            imgBlk_G = G(((blkIdxH-1)*blockHight+1):(blkIdxH*blockHight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth));
            imgBlk_B = B(((blkIdxH-1)*blockHight+1):(blkIdxH*blockHight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth));
            
            for pixelIdx_H = 1:blockHight
                for pixelIdx_W = 1:blockWidth
                    localHistR(imgBlk_R(pixelIdx_H,pixelIdx_W) +1) = localHistR(imgBlk_R(pixelIdx_H,pixelIdx_W) +1) + 1;
                    localHistG(imgBlk_G(pixelIdx_H,pixelIdx_W) +1) = localHistG(imgBlk_G(pixelIdx_H,pixelIdx_W) +1) + 1;
                    localHistB(imgBlk_B(pixelIdx_H,pixelIdx_W) +1) = localHistB(imgBlk_B(pixelIdx_H,pixelIdx_W) +1) + 1;
                end
            end
            localHistofOneImg(blkIdx,:) = [localHistR localHistG localHistB];
            blkIdx = blkIdx +1;
            
        end
    end
    localHistograms{imgIdx} = localHistofOneImg;
     
end
runningTime = toc;
disp('End of BOEWFunc_GenLocalBlockHistogramHSV.');
end



