function HSVImgEnc = BOEWFunc_HSVBlockPermute(HSVImg,blockHeight,blockWidth,ImgID)
    [imgHeight,imgWidth,~] = size(HSVImg);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blkNum = blkNumH*blkNumW;
    blks = cell(blkNum,1);
    HSVImgEnc = HSVImg;
    s = RandStream('mt19937ar','Seed',ImgID);
    rp = randperm(s,blkNum);    

    blkIdxInEncdImg = 1;  
    for blkIdxH_E = 1:blkNumH
        for blkIdxW_E = 1:blkNumW
        blkIdxInOriginalImg = rp(blkIdxInEncdImg);

        
        blkIdxH_O = uint32(floor((blkIdxInOriginalImg-1)/blkNumW) + 1);
        blkIdxW_O = uint32(mod(blkIdxInOriginalImg - 1,blkNumW)+1);
        
        HSVImgEnc(((blkIdxH_E-1)*blockHeight+1):(blkIdxH_E*blockHeight),((blkIdxW_E-1)*blockWidth+1):(blkIdxW_E*blockWidth),:) = ...
            HSVImg(((blkIdxH_O-1)*blockHeight+1):(blkIdxH_O*blockHeight),((blkIdxW_O-1)*blockWidth+1):(blkIdxW_O*blockWidth),:);
        
        blkIdxInEncdImg = blkIdxInEncdImg + 1;
        
        end
    end
    
 
 
end