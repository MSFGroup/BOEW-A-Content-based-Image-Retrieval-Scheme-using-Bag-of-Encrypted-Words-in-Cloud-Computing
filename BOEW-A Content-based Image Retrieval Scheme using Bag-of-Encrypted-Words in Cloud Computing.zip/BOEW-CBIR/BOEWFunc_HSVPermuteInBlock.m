function HSVImgEnc = BOEWFunc_HSVPermuteInBlock(HSVImg,blockHeight,blockWidth,ImgID)
    [imgHeight,imgWidth,~] = size(HSVImg);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blksize = blockHeight * blockWidth;
    %blkNum = blkNumH*blkNumW;

    blkIdx = 1;             
     
    for blkIdxH = 1:blkNumH
        for blkIdxW = 1:blkNumW
            ss1 = uint32(log2(blkIdx) + 1);
            ss2 = bitshift(ImgID,ss1);
            ss3 = bitor(ss2,blkIdx);
            s = RandStream('mt19937ar','Seed',ss3);
            rp = randperm(s,blksize); 
            rp = reshape(rp,blockHeight,blockWidth); 
            
            blkH = HSVImg(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1);
            blkS = HSVImg(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2);
            blkV = HSVImg(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3);            
            
           
            HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1) = blkH(rp);
            HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2) = blkS(rp);
            HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3) = blkV(rp);



            
            blkIdx = blkIdx + 1;
         end
    end
    
 
end