function HSVImgEnc = BOEWFunc_HSVValuePermute(HSVImg,keyH,keyS,keyV)
    [imgHeight,imgWidth,~] = size(HSVImg);
    
    sH = RandStream('mt19937ar','Seed',keyH);
    sS = RandStream('mt19937ar','Seed',keyS);
    sV = RandStream('mt19937ar','Seed',keyV);
    
    rpH = uint8(randperm(sH,101));
    rpS = uint8(randperm(sS,101));
    rpV = uint8(randperm(sV,101));
  
    HSVImg = int8(floor(HSVImg * 100));
    H = HSVImg(:,:,1);
    S = HSVImg(:,:,2);
    V = HSVImg(:,:,3);


     for pixelValue =0:100
        idx=find(HSVImg(:,:,1) == pixelValue);
        H(idx) = rpH(pixelValue+1);

        idx=find(HSVImg(:,:,2) == pixelValue);
        S(idx) = rpS(pixelValue+1);
        
        idx=find(HSVImg(:,:,3) == pixelValue);
        V(idx) = rpV(pixelValue+1);
           
     end   
    HSVImgEnc(:,:,1) = H;
    HSVImgEnc(:,:,2) = S;
    HSVImgEnc(:,:,3) = V;
    HSVImgEnc = double(HSVImgEnc)/100.0;
end










