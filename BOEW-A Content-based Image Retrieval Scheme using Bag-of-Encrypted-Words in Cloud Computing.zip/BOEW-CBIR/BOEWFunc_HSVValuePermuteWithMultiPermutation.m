function image=BOEWFunc_HSVValuePermuteWithMultiPermutation(img,keys,tableNum)
% clear all
% clc
% number=2;
% img=imread('1.jpg');

hsv= rgb2hsv(img);
HSV=uint8(round(hsv*100));%
H= HSV( :, :, 1);
S= HSV( :, :, 2);
V= HSV( :, :, 3);

[M,N]=size(H);
ImgLen=M*N;
H=H(:);S=S(:);V=V(:);
keyHs = keys{1};keySs = keys{2};keyVs = keys{3};

% ---------------------------����ֵ�û�����----------------------
randomH= 1+fix(tableNum*rand(1,ImgLen));%Generate random number [1 tableNum]
randomS= 1+fix(tableNum*rand(1,ImgLen));
randomV= 1+fix(tableNum*rand(1,ImgLen));
for i=1:ImgLen
    KeyH=keyHs(randomH(i),:);
    KeyS=keySs(randomS(i),:);
    KeyV=keyVs(randomV(i),:);
    EH(i)=KeyH((H(i)+1));
    ES(i)=KeyS((S(i)+1));
    EV(i)=KeyV((V(i)+1));
end
Hmoto=reshape(EH,M,N);
Smoto=reshape(ES,M,N);
Vmoto=reshape(EV,M,N);

image(:,:,1)=Hmoto;
image(:,:,2)=Smoto;
image(:,:,3)=Vmoto;

%image = double(image)/100.0;
%image = uint8(round(hsv2rgb(image)*255));
        

