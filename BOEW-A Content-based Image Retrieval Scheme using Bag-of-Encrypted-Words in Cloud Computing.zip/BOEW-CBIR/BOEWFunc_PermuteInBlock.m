function ImgEnc = BOEWFunc_PermuteInBlock(Img,blockHeight,blockWidth,ImgID)
    [imgHeight,imgWidth,~] = size(Img);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blksize = blockHeight * blockWidth;
    %blkNum = blkNumH*blkNumW;

    blkIdx = 1;             
    ImgEnc =  Img;
    for blkIdxH = 1:blkNumH
        for blkIdxW = 1:blkNumW
            ss1 = uint32(log2(blkIdx) + 1);
            ss2 = bitshift(ImgID,ss1);
            ss3 = bitor(ss2,blkIdx);
            s = RandStream('mt19937ar','Seed',ss3);
            rp = randperm(s,blksize); 
            %rp = reshape(rp,blockHeight,blockWidth); 
            
            blkH = Img(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1);
            blkS = Img(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2);
            blkV = Img(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3); 
            blkH = reshape(blkH,1,blksize);
            blkS = reshape(blkS,1,blksize);
            blkV = reshape(blkV,1,blksize);
            blkH = blkH(rp);
            blkS = blkS(rp);
            blkV = blkV(rp);
            blkH = reshape(blkH,blockHeight,blockWidth);
            blkS = reshape(blkS,blockHeight,blockWidth);
            blkV = reshape(blkV,blockHeight,blockWidth);            
           
            ImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1) = blkH;
            ImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2) = blkS;
            ImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3) = blkV;
            
            blkIdx = blkIdx + 1;
         end
    end
    
    
 
end