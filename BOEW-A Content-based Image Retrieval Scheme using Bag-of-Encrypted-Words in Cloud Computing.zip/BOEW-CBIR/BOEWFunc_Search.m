%   clc;
clear;
strFeatureFolder = 'E:\INRIA HOLIDAYS DATASET\BOEW-CBIR\';

colorSpace = 'BOEW_HSV_';
blockHeight = 25;
blockWidth = 25;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 64;%% 50*50ʱ���� ���ó�4���ɴ����ơ�
clusterNum              = 8000;%% Ŀǰ100����á�
maxIter                 = 300;%% ��ʱ�����������
clusterDistanceType     = 'cityblock';%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
strInriaDataFileSavePath = 'E:\INRIA HOLIDAYS DATASET\eval_holidays';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% load Features
strDataLoad = colorSpace;
strDataLoad = [strDataLoad int2str(blockHeight) '_'];
strDataLoad = [strDataLoad int2str(blockWidth) '_'];
strDataLoad = [strDataLoad 'clusterDistanceType=' clusterDistanceType '_'];
strDataLoad = [strDataLoad 'step=' int2str(localFeatureSelectStep) '_'];
strDataLoad = [strDataLoad 'clusterNum=' int2str(clusterNum) '_'];
strDataLoad = [strDataLoad 'maxIter=' int2str(maxIter) '_globalFeatures_normalized.mat'];
dataFeatures = load(strDataLoad);
Features = dataFeatures.globalFeatures;

dataInriaImageClassInfo = load('InriaImageClassInfo.mat');
imgClass = dataInriaImageClassInfo.InriaImageClassInfo;
distanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�


    tic;
    imgNum = size(Features,1);
    classNum = size(imgClass,1);
    strImgFolder = 'E:\INRIA HOLIDAYS DATASET\Images\';
  dirOutput = dir(fullfile(strImgFolder,'*.jpg'));
 imgNames={dirOutput.name};

    for classIdx = 1:classNum
        queryImageName = strcat(int2str(1000 + classIdx -1),'00.jpg');
        for imgIdx = 1:imgNum
            if queryImageName == imgNames{imgIdx}
                queryFeature= Features(imgIdx,:);
            end
        end
           %%%%%%%%%%%%%%
         %similarDistance = pdist2(queryFeature,Features,distanceType);% 
         similarDistance = (1:1491);
         for iii = 1:1491
             similarDistance(iii) = pdist2(queryFeature,Features(iii,:),distanceType);
         end
         
        [~,Idx]=sort(similarDistance);% similarDistance is a 1-D vector
 

        strRst{classIdx} = queryImageName;
        for rankedImgIdx = 1:10
            strIdx = int2str(rankedImgIdx-1);
            strRst{classIdx} = [strRst{classIdx},strIdx,imgNames(Idx(rankedImgIdx))];
        end 
        
        %%%%%%%%%%%%%%%%%
        thisClass = imgClass{classIdx};
        thisClassNum = size(thisClass,2);  
        for rankedImgIdx = 11:imgNum
            for thisClassIdx = 1:thisClassNum
                if strcmp( imgNames{Idx(rankedImgIdx)},thisClass{thisClassIdx} )
                    strIdx = int2str(rankedImgIdx-1);
                    strRst{classIdx} = [strRst{classIdx},strIdx,imgNames(Idx(rankedImgIdx))];
                end
            end
        end

    end
    %% make file
%     fid = fopen(strSavePath,'w');
%     for classIdx = 1:classNum
%         temp = strRst{classIdx};
%         thisClassNum = size(temp,2);
%         for j =1:thisClassNum
%            fprintf(fid,'%s ',temp{j}); 
%         end
%         fprintf(fid,'\n');
%     end
%     fclose(fid);
    toc



