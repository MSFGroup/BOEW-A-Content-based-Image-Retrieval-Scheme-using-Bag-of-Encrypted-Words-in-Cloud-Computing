function [dataNew] = BOEWFunc_SelectDataRowByRow(data,step)
    dataNum = size(data,1);
    idx = 1:step:dataNum;
    dataNew = data(idx,:);    
end
