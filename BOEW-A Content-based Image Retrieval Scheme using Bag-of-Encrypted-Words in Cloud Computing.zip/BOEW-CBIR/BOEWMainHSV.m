clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% �����趨
strImgFolder = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\';
blockHight = 50;
blockWidth = 50;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 4;%% 50*50ʱ���� ���ó�4���ɴ����ơ�
ClusterNum              = 100;%% Ŀǰ100����á�
maxIter                 = 300;%% ��ʱ�����������
clusterDistanceType     = 'cityblock';%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
strInriaDataFileSavePath = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\eval_holidays';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ����ֲ�ֱ��ͼ
[imgNames,localHistograms,runningTime] = BOEWFunc_GenLocalBlockHistogramHSV(strImgFolder,blockHight,blockWidth);
strDataSave = 'BOEW_HSV_';
strDataSave = [strDataSave int2str(blockHight) '_'];
strDataSave = [strDataSave int2str(blockWidth) '_'];
strDataSave = [strDataSave 'LocalHistograms'];
save([strDataSave '.mat'],'imgNames','localHistograms','runningTime', '-v7.3');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localHistogramPure = cell2mat(localHistograms);
strDataSave = [strDataSave '_Pure'];
save([strDataSave '.mat'],'localHistogramPure', '-v7.3');
%% �Ѿֲ�ֱ��ͼ����һ�������Է�������



