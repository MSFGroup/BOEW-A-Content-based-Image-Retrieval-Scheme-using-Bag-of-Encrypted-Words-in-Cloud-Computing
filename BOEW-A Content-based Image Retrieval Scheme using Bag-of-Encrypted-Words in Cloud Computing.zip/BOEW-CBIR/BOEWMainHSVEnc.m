clear;
clc;
strImgFolder = 'E:\INRIA HOLIDAYS DATASET\Images\';
dirOutput = dir(fullfile(strImgFolder,'*.jpg'));
imgNames={dirOutput.name};
imageNum = size(imgNames,2); 
keyH = 1; keyS = 2; keyV = 3;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 10
blockWidth = 10;
%imageNum =1;
i = 1;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    %HSVImgEnc = int8(floor(HSVImgEnc * 100));
    HSVImgEnc = BOEWFunc_HSVBlockPermute(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVPermuteInBlock(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVValuePermute(HSVImgEnc,keyH,keyS,keyV);
   % HSVImgEnc = double(HSVImgEnc)/100.0;
   % HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end

time(i) = toc
i = i +1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 15
blockWidth = 15;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    HSVImgEnc = BOEWFunc_HSVBlockPermute(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVPermuteInBlock(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVValuePermute(HSVImgEnc,keyH,keyS,keyV);
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc
i = i +1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 20
blockWidth = 20;
tic
for imgIdx = 1:imageNum
   disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    HSVImgEnc = BOEWFunc_HSVBlockPermute(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVPermuteInBlock(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVValuePermute(HSVImgEnc,keyH,keyS,keyV);
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc
i = i +1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 25
blockWidth = 25;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    HSVImgEnc = BOEWFunc_HSVBlockPermute(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVPermuteInBlock(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVValuePermute(HSVImgEnc,keyH,keyS,keyV);
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc
i = i +1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 50
blockWidth = 50;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    HSVImgEnc = BOEWFunc_HSVBlockPermute(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVPermuteInBlock(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVValuePermute(HSVImgEnc,keyH,keyS,keyV);
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc
i = i +1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 100
blockWidth = 100;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    HSVImgEnc = BOEWFunc_HSVBlockPermute(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVPermuteInBlock(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVValuePermute(HSVImgEnc,keyH,keyS,keyV);
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc
i = i +1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 200
blockWidth = 200;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    HSVImgEnc = BOEWFunc_HSVBlockPermute(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVPermuteInBlock(HSVImgEnc,blockHeight,blockWidth,imgIdx);
    HSVImgEnc = BOEWFunc_HSVValuePermute(HSVImgEnc,keyH,keyS,keyV);
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc
i = i +1;