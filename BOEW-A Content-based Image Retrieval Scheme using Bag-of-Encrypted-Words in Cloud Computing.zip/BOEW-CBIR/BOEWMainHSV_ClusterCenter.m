%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

blksize = [15,20,25,50,100,200];
localFeatureSelectStepSet = [400,100,64,16,4,1];
strDataLoad = 'D:\XZH\ExperimentData\withEncAllDifPmtNum\';
strDataSave = 'D:\XZH\ExperimentData\withEncAllDifPmtNum\';
colorSpace = 'BOEW_HSV_EncAll_';

for tableNum =  [1]%,2,3,4,5,10,20,50,100,200,500
     for blksizeIdx = [3]% [1,2,3,4,5,6]
        for clusterNum = [5000]% [100,500,1000,2000,3000,4000,5000,8000]
            for localFeatureSelectStep = [1024,512,256,128,64,32,16,8]
            
                blockHeight = blksize(blksizeIdx);
                blockWidth = blksize(blksizeIdx);
                %localFeatureSelectStep  = localFeatureSelectStepSet(blksizeIdx);%% 50*50ʱ���� ���ó�4���ɴ����ơ�
                disp(['blksize    ' int2str(blockHeight) '    localFeatureSelectStep    ' int2str(localFeatureSelectStep) '    clusterNum    ' int2str(clusterNum) ' localFeatureSelectStep  ' int2str(localFeatureSelectStep)]);
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                maxIter                 = 300;%% ��ʱ�����������
                clusterDistanceType     = 'cityblock';%%
                globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %% ���ؾֲ�ֱ��ͼ/ѡ�񲿷�ֱ��ͼ/�����γɾ�������
                strDataLoad1 =[strDataLoad colorSpace];
                strDataLoad1 = [strDataLoad1 int2str(blockHeight) '_'];
                strDataLoad1 = [strDataLoad1 int2str(blockWidth) '_'];
                strDataLoad1 = [strDataLoad1 int2str(tableNum) '_'];
                strDataLoad1 = [strDataLoad1 'LocalHistograms.mat'];

                data = []; C = [];runningtime = [];
                data = load(strDataLoad1);
                [seletedLocalHistForCluster] = BOEWFunc_SelectLocalHistForCluster(data.localHistograms,localFeatureSelectStep);
                [C,runningtime] = BOEWFunc_GenClusterCenter(seletedLocalHistForCluster,clusterNum,maxIter,clusterDistanceType);
                %% save
                strDataSave1 = [strDataSave colorSpace];
                strDataSave1 = [strDataSave1 int2str(blockHeight) '_'];
                strDataSave1 = [strDataSave1 int2str(blockWidth) '_'];
                strDataSave1 = [strDataSave1 int2str(tableNum) '_'];
                strDataSave1 = [strDataSave1 'clusterDistanceType=' clusterDistanceType '_'];
                strDataSave1 = [strDataSave1 'step=' int2str(localFeatureSelectStep) '_'];
                strDataSave1 = [strDataSave1 'clusterNum=' int2str(clusterNum) '_'];
                strDataSave1 = [strDataSave1 'maxIter=' int2str(maxIter) '_clusterCenter.mat'];

                save(strDataSave1,'C','runningtime', '-v7.3');
            end
        end
    end

end
