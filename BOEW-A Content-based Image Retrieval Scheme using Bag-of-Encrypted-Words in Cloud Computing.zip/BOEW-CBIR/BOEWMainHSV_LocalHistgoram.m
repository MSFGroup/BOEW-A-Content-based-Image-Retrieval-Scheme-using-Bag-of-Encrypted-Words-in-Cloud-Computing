clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%for tableNum =  [1,2,3,4,5,10,20,50,100,200,500]
for blksize = [15,20,25,50,100,200]
    disp(['blksize           ' int2str(blksize)]);
    %% �����趨
    strImgFolder = ['D:\XZH\EncImg_withDifBlkSize\EncImg_Blk' int2str(blksize) '\'];
    %strImgFolder = 'D:\INRIAHOLIDAYSImages\';
    %colorSpace = 'BOEW_RGB_';
    %colorSpace = 'BOEW_YUV_';
    colorSpace = 'BOEW_HSV_EncAll_';
    blockHight = blksize;
    blockWidth = blksize;
    tableNum = 1;

    strDataSavePath = 'D:\XZH\ExperimentData\withEncAllDifBlkSize\';
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% ����ֲ�ֱ��ͼ
    [imgNames,localHistograms,runningTime] = BOEWFunc_GenLocalBlockHistogramHSV(strImgFolder,blockHight,blockWidth);
    %[imgNames,localHistograms,runningTime] = BOEWFunc_GenLocalBlockHistogramRGB(strImgFolder,blockHight,blockWidth);
    %[imgNames,localHistograms,runningTime] = BOEWFunc_GenLocalBlockHistogramYUV(strImgFolder,blockHight,blockWidth);

    strDataSave = [strDataSavePath colorSpace];% BOEW_HSV_
    strDataSave = [strDataSave int2str(blockHight) '_'];
    strDataSave = [strDataSave int2str(blockWidth) '_'];
    strDataSave = [strDataSave int2str(tableNum) '_'];
    strDataSave = [strDataSave 'LocalHistograms.mat'];
    save(strDataSave,'imgNames','localHistograms','runningTime', '-v7.3');
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
%end





