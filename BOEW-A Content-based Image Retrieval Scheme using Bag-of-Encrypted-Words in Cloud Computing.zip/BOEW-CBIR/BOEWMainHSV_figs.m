clear all;
clc;
data = load('GlobalHistogramHSVRound.mat');
strSavePath = 'E:\MyNetDisk\01ѧ�������޸�\2015-������\BOEW-TIFS-Rerived-20170426\Fig\';
picH = 150;
picW = 600;
fsize = 12;

histograms = data.Histograms;
%histogramsTOdraw = mean(histograms);
histogramsTOdraw = histograms(100,:);



H = histogramsTOdraw(1:101);
S = histogramsTOdraw(102:202);
V = histogramsTOdraw(203:303);


%figures; 
ax = subplot(3,1,1);
%figures = figure('Position',[100,100,picW,picH]);
figure = bar(ax,H);
%axes1 = axes('FontSize',fsize,'Parent',figure);
xlabel(ax,'Value in H component');
xlim([1 101])
ylabel(ax,'Ratio');
 %title('{\it Q}=1','FontSize',12);
box(ax,'on');
grid(ax,'on');
hold(ax,'all');   

ax = subplot(3,1,2);
%figures = figure('Position',[100,100,picW,picH]);
figure = bar(ax,S);
%axes1 = axes('FontSize',fsize,'Parent',figure);
xlabel(ax,'Value in S component');
xlim([1 101])
ylabel(ax,'Ratio');
 %title('{\it Q}=1','FontSize',12);
box(ax,'on');
grid(ax,'on');
hold(ax,'all'); 
ax = subplot(3,1,3);
%figures = figure('Position',[100,100,picW,picH]);
figure = bar(ax,V);
%axes1 = axes('FontSize',fsize,'Parent',figure);
xlabel(ax,'Value in V component');
xlim([1 101])
ylabel(ax,'Ratio');
 %title('{\it Q}=1','FontSize',12);
box(ax,'on');
grid(ax,'on');
hold(ax,'all'); 
saveas(figure,[strSavePath 'HistOneImg.eps'],'epsc2');







