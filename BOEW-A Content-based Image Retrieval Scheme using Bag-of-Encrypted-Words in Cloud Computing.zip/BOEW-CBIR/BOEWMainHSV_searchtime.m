clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% �����趨
strImgFolder = 'E:\INRIA HOLIDAYS DATASET\Images\';
%colorSpace = 'BOEW_RGB_';
colorSpace = 'BOEW_HSV_';
blockHeight = 25;
blockWidth = 25;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 64%% 50*50ʱ���� ���ó�4���ɴ����ơ�
clusterNum              = 2000;%% Ŀǰ100����á�
maxIter                 = 300;%% ��ʱ�����������
clusterDistanceType     = 'cityblock';%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
strInriaDataFileSavePath = 'E:\INRIA HOLIDAYS DATASET\eval_holidays';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %% load cluster centers
strDataLoad = colorSpace;
strDataLoad = [strDataLoad int2str(blockHeight) '_'];
strDataLoad = [strDataLoad int2str(blockWidth) '_'];
strDataLoad = [strDataLoad 'clusterDistanceType=' clusterDistanceType '_'];
strDataLoad = [strDataLoad 'step=' int2str(localFeatureSelectStep) '_'];
strDataLoad = [strDataLoad 'clusterNum=' int2str(clusterNum) '_'];
strDataLoad = [strDataLoad 'maxIter=' int2str(maxIter) '_clusterCenter.mat'];
dataCenters = load(strDataLoad);
%% load local histograms
strDataLoad = colorSpace;
strDataLoad = [strDataLoad int2str(blockHeight) '_'];
strDataLoad = [strDataLoad int2str(blockWidth) '_'];
strDataLoad = [strDataLoad 'LocalHistograms.mat'];
dataLocalHistograms = load(strDataLoad);
imgNames = dataLocalHistograms.imgNames;
localHistograms = dataLocalHistograms.localHistograms;

%% Generate global features
clusterCenters = dataCenters.C;
% globalFeatures = BOEWFunc_GenGlobalFeature(localHistograms,clusterCenters,clusterDistanceType);
strDataSave = colorSpace;
strDataSave = [strDataSave int2str(blockHeight) '_'];
strDataSave = [strDataSave int2str(blockWidth) '_'];
strDataSave = [strDataSave 'clusterDistanceType=' clusterDistanceType '_'];
strDataSave = [strDataSave 'step=' int2str(localFeatureSelectStep) '_'];
strDataSave = [strDataSave 'clusterNum=' int2str(clusterNum) '_'];
strDataSave = [strDataSave 'maxIter=' int2str(maxIter) '_globalFeatures_normalized.mat'];
data = load(strDataSave);
globalFeatures = data.globalFeatures;
% 
% save(strDataSave,'globalFeatures', '-v7.3');
%% generate Inria data file and calculate mAP values
dataInriaImageClassInfo = load('InriaImageClassInfo.mat');
imgClass = dataInriaImageClassInfo.InriaImageClassInfo;

strSavePath = 'E:\INRIA HOLIDAYS DATASET\eval_holidays\';
strSavePath = [strSavePath colorSpace];
strSavePath = [strSavePath int2str(blockHeight) '_'];
strSavePath = [strSavePath int2str(blockWidth) '_'];
strSavePath = [strSavePath 'clusterDistanceType=' clusterDistanceType '_'];
strSavePath = [strSavePath 'step=' int2str(localFeatureSelectStep) '_'];
strSavePath = [strSavePath 'clusterNum=' int2str(clusterNum) '_'];
strSavePath = [strSavePath 'maxIter=' int2str(maxIter) '_normalized_InriaDataFile.dat'];
%data = load(strSavePath);
BOEWFunc_Search(globalFeatures,imgNames,imgClass,globalFeatureDistanceType,strSavePath);

%% call system to run python
% strCommend = 'python E:\INRIA HOLIDAYS DATASET\eval_holidays\holidays_map.py ';
% strCommend = [strCommend strSavePath];
% [status, results]=system(strCommend);



%function mydialog
%     d = dialog('Position',[300 300 250 150],'Name','My Dialog');
% 
%     txt = uicontrol('Parent',d,...
%                'Style','text',...
%                'Position',[20 80 210 40],...
%                'String','Finished.');
% 
%     btn = uicontrol('Parent',d,...
%                'Position',[85 20 70 25],...
%                'String','Close',...
%                'Callback','delete(gcf)');
%end




