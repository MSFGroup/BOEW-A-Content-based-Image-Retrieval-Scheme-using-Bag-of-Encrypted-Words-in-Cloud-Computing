clc;
clear;
imgInfo = load('InriaImageClassInfo.mat');
imgNames = imgInfo.imgNames;
imgClass = imgInfo.imgClass;
Features = load('');
distanceType = 'euclidean';%'cityblock';
strSavePath='';
BOEWFunc_GenInriaRstDat(Features,imgNames,imgClass,distanceType,strSavePath);
