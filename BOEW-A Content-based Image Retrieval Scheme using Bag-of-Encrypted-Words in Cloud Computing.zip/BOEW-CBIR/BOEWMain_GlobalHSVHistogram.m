clear;
clc;
strImgFolder = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\ExperimentData\EncImgs\';
disp('In BOEWMain_GlobalHSVHistogram...');
dirOutput = dir(fullfile(strImgFolder,'*.jpg'));
imgNames={dirOutput.name};

imageNum = size(imgNames,2);
%imageNum = 1491;
Histograms = zeros(imageNum,303);%%%  imageNum
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
for imgIdx = 1:imageNum %%%  imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     H = image(:,:,1);
%     S = image(:,:,2);
%     V = image(:,:,3);
    [H,S,V]=rgb2hsv(image);
    H = uint8(round(H * 100));
    S = uint8(round(S * 100));
    V = uint8(round(V * 100));    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [imgHight,imgWidth] = size(H);

    HistH = zeros(1,101);
    HistS = zeros(1,101);
    HistV = zeros(1,101);
    for pixelIdx_H = 1:imgHight
        for pixelIdx_W = 1:imgWidth
            HistH(H(pixelIdx_H,pixelIdx_W) +1) = HistH(H(pixelIdx_H,pixelIdx_W) +1) + 1;
            HistS(S(pixelIdx_H,pixelIdx_W) +1) = HistS(S(pixelIdx_H,pixelIdx_W) +1) + 1;
            HistV(V(pixelIdx_H,pixelIdx_W) +1) = HistV(V(pixelIdx_H,pixelIdx_W) +1) + 1;
        end
    end
 
    Histograms(imgIdx,:) = [HistH/sum(HistH) HistS/sum(HistS) HistV/sum(HistV)];
     
end
save([strImgFolder 'GlobalHistogramHSVRoundJPEG.mat'],'Histograms', '-v7.3');
runningTime = toc;