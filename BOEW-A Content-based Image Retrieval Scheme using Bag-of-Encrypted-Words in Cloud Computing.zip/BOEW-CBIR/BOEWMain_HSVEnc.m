clc;
clear;
for tableNum = [1,2,3,4,5,10,20,50,100,200,500]
    for blksize = [25];%[15,20,25,50,100,200]
        keys=[];%���ڴ洢��������Կ
        blockHeight = blksize;
        blockWidth = blksize;
        %tableNum = 1;


        strImgFolder = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\';
        %strImgFolder = ['D:\XZH\EncImg_with' int2str(tableNum) 'Permutations\']
        %strImgFolder = ['D:\XZH\EncImg_withOnlyPixelSubstitution\EncImg_with1Permutations\']
        dirOutput = dir(fullfile(strImgFolder,'*.jpg'));
        imgNames={dirOutput.name};
        imageNum = size(imgNames,2); 

        tic;


        %strImgSaveFolder = ['E:\MyNetDisk\INRIA HOLIDAYS DATASET\ExperimentData\EncImg-4' int2str(blksize) '\'];%int2str(tableNum)
        strImgSaveFolder = ['E:\MyNetDisk\INRIA HOLIDAYS DATASET\ExperimentData\EncImg-4\'];%int2str(tableNum)


        keyHs=[];keySs=[];keyVs=[];
        for i=1:tableNum
            key=randperm(101)-1;
            keyHs=[keyHs;key];

            key=randperm(101)-1;
            keySs=[keySs;key];

            key=randperm(101)-1;
            keyVs=[keyVs;key];
        end

        keys = {uint8(keyHs),uint8(keySs),uint8(keyVs)};

        for imgIdx=[9] %1:1491
            disp(['blksize=' int2str(blksize) '          imgIdx=' int2str(imgIdx)]);
            ImagePath=strcat(strImgFolder,imgNames{imgIdx});
            img=imread(ImagePath);


            img = BOEWFunc_HSVValuePermuteWithMultiPermutation(img,keys,tableNum);
            img = BOEWFunc_PermuteInBlock(img,blockHeight,blockWidth,imgIdx);
            img = BOEWFunc_PermuteBlock(img,blockHeight,blockWidth,imgIdx);

            strImgSave =imgNames{imgIdx};
            strImgSave =strImgSave(1:6);
            strImgSave =[strImgSaveFolder strImgSave '_' int2str(tableNum) '.png'];
            imwrite(img,strImgSave)

        end
        runningTime = toc;
        save([strImgSaveFolder  'EncTime.mat'],'runningTime', '-v7.3');
    end
end
