%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% �����趨
strImgFolder = 'E:\INRIA HOLIDAYS DATASET\Images\';
%colorSpace = 'BOEW_RGB_';
%colorSpace = 'BOEW_YUV_';
colorSpace = 'BOEW_HSV_';
blockHeight = 10
blockWidth = 10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 400;%% 50*50ʱ���� ���ó�4���ɴ����ơ�
clusterNum              = 2000;%% Ŀǰ100����á�
maxIter                 = 300;%% ��ʱ�����������
clusterDistanceType     = 'cityblock';%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
strInriaDataFileSavePath = 'E:\INRIA HOLIDAYS DATASET\eval_holidays';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ����ֲ�ֱ��ͼ
strDataLoad =colorSpace;
strDataLoad = [strDataLoad int2str(blockHeight) '_'];
strDataLoad = [strDataLoad int2str(blockWidth) '_'];
strDataLoad = [strDataLoad 'LocalHistograms.mat'];
data = load(strDataLoad);
runningTime = data.runningTime
[seletedLocalHistForCluster] = BOEWFunc_SelectLocalHistForCluster(data.localHistograms,localFeatureSelectStep);
%clear data;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
%clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% �����趨
strImgFolder = 'E:\INRIA HOLIDAYS DATASET\Images\';
%colorSpace = 'BOEW_RGB_';
%colorSpace = 'BOEW_YUV_';
colorSpace = 'BOEW_HSV_';
blockHeight = 15
blockWidth = 15;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 400;%% 50*50ʱ���� ���ó�4���ɴ����ơ�
clusterNum              = 2000;%% Ŀǰ100����á�
maxIter                 = 300;%% ��ʱ�����������
clusterDistanceType     = 'cityblock';%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
strInriaDataFileSavePath = 'E:\INRIA HOLIDAYS DATASET\eval_holidays';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ����ֲ�ֱ��ͼ
strDataLoad =colorSpace;
strDataLoad = [strDataLoad int2str(blockHeight) '_'];
strDataLoad = [strDataLoad int2str(blockWidth) '_'];
strDataLoad = [strDataLoad 'LocalHistograms.mat'];
data = load(strDataLoad);
runningTime = data.runningTime
[seletedLocalHistForCluster] = BOEWFunc_SelectLocalHistForCluster(data.localHistograms,localFeatureSelectStep);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
%clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% �����趨
strImgFolder = 'E:\INRIA HOLIDAYS DATASET\Images\';
%colorSpace = 'BOEW_RGB_';
%colorSpace = 'BOEW_YUV_';
colorSpace = 'BOEW_HSV_';
blockHeight = 20
blockWidth = 20;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 100;%% 50*50ʱ���� ���ó�4���ɴ����ơ�
clusterNum              = 2000;%% Ŀǰ100����á�
maxIter                 = 300;%% ��ʱ�����������
clusterDistanceType     = 'cityblock';%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
strInriaDataFileSavePath = 'E:\INRIA HOLIDAYS DATASET\eval_holidays';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ����ֲ�ֱ��ͼ
strDataLoad =colorSpace;
strDataLoad = [strDataLoad int2str(blockHeight) '_'];
strDataLoad = [strDataLoad int2str(blockWidth) '_'];
strDataLoad = [strDataLoad 'LocalHistograms.mat'];
data = load(strDataLoad);
runningTime = data.runningTime
[seletedLocalHistForCluster] = BOEWFunc_SelectLocalHistForCluster(data.localHistograms,localFeatureSelectStep);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
%clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% �����趨
strImgFolder = 'E:\INRIA HOLIDAYS DATASET\Images\';
%colorSpace = 'BOEW_RGB_';
%colorSpace = 'BOEW_YUV_';
colorSpace = 'BOEW_HSV_';
blockHeight = 25
blockWidth = 25;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 64;%% 50*50ʱ���� ���ó�4���ɴ����ơ�
clusterNum              = 2000;%% Ŀǰ100����á�
maxIter                 = 300;%% ��ʱ�����������
clusterDistanceType     = 'cityblock';%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
strInriaDataFileSavePath = 'E:\INRIA HOLIDAYS DATASET\eval_holidays';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ����ֲ�ֱ��ͼ
strDataLoad =colorSpace;
strDataLoad = [strDataLoad int2str(blockHeight) '_'];
strDataLoad = [strDataLoad int2str(blockWidth) '_'];
strDataLoad = [strDataLoad 'LocalHistograms.mat'];
data = load(strDataLoad);
runningTime = data.runningTime
[seletedLocalHistForCluster] = BOEWFunc_SelectLocalHistForCluster(data.localHistograms,localFeatureSelectStep);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
%clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% �����趨
strImgFolder = 'E:\INRIA HOLIDAYS DATASET\Images\';
%colorSpace = 'BOEW_RGB_';
%colorSpace = 'BOEW_YUV_';
colorSpace = 'BOEW_HSV_';
blockHeight = 50
blockWidth = 50;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 16;%% 50*50ʱ���� ���ó�4���ɴ����ơ�
clusterNum              = 2000;%% Ŀǰ100����á�
maxIter                 = 300;%% ��ʱ�����������
clusterDistanceType     = 'cityblock';%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
strInriaDataFileSavePath = 'E:\INRIA HOLIDAYS DATASET\eval_holidays';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ����ֲ�ֱ��ͼ
strDataLoad =colorSpace;
strDataLoad = [strDataLoad int2str(blockHeight) '_'];
strDataLoad = [strDataLoad int2str(blockWidth) '_'];
strDataLoad = [strDataLoad 'LocalHistograms.mat'];
data = load(strDataLoad);
runningTime = data.runningTime
[seletedLocalHistForCluster] = BOEWFunc_SelectLocalHistForCluster(data.localHistograms,localFeatureSelectStep);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
%clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% �����趨
strImgFolder = 'E:\INRIA HOLIDAYS DATASET\Images\';
%colorSpace = 'BOEW_RGB_';
%colorSpace = 'BOEW_YUV_';
colorSpace = 'BOEW_HSV_';
blockHeight = 100
blockWidth = 100;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 4;%% 50*50ʱ���� ���ó�4���ɴ����ơ�
clusterNum              = 2000;%% Ŀǰ100����á�
maxIter                 = 300;%% ��ʱ�����������
clusterDistanceType     = 'cityblock';%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
strInriaDataFileSavePath = 'E:\INRIA HOLIDAYS DATASET\eval_holidays';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ����ֲ�ֱ��ͼ
strDataLoad =colorSpace;
strDataLoad = [strDataLoad int2str(blockHeight) '_'];
strDataLoad = [strDataLoad int2str(blockWidth) '_'];
strDataLoad = [strDataLoad 'LocalHistograms.mat'];
data = load(strDataLoad);
runningTime = data.runningTime
[seletedLocalHistForCluster] = BOEWFunc_SelectLocalHistForCluster(data.localHistograms,localFeatureSelectStep);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
%clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% �����趨
strImgFolder = 'E:\INRIA HOLIDAYS DATASET\Images\';
%colorSpace = 'BOEW_RGB_';
%colorSpace = 'BOEW_YUV_';
colorSpace = 'BOEW_HSV_';
blockHeight = 200
blockWidth = 200;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 1;%% 50*50ʱ���� ���ó�4���ɴ����ơ�
clusterNum              = 2000;%% Ŀǰ100����á�
maxIter                 = 300;%% ��ʱ�����������
clusterDistanceType     = 'cityblock';%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
globalFeatureDistanceType = 'cityblock';%% cityblock ��euclideanͨ��Ҫ�á�
strInriaDataFileSavePath = 'E:\INRIA HOLIDAYS DATASET\eval_holidays';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ����ֲ�ֱ��ͼ
strDataLoad =colorSpace;
strDataLoad = [strDataLoad int2str(blockHeight) '_'];
strDataLoad = [strDataLoad int2str(blockWidth) '_'];
strDataLoad = [strDataLoad 'LocalHistograms.mat'];
data = load(strDataLoad);
runningTime = data.runningTime
[seletedLocalHistForCluster] = BOEWFunc_SelectLocalHistForCluster(data.localHistograms,localFeatureSelectStep);