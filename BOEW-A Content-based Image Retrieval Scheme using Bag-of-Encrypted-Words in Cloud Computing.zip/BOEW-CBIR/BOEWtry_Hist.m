clc;
clear;
I = imread('E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\100300.jpg');
hsv1 = rgb2hsv(I);
hsv2 = uint8(round(hsv1*100.0));
Num2 = size(find(hsv2(:,:,1) == 0),1); 

%hsv3 = double(hsv2)/100.0;  
%I1 = uint8(round(hsv2rgb(hsv1)*255));%

imwrite(hsv2,'E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\100300.png')
I3 = imread('E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\100300.png');
%hsv4 = rgb2hsv(I3);
%hsv4 = uint8(round(hsv4*100));
h4 = I3(:,:,1);

Num4 = size(find(h4 == 0),1); 






% dif = double(hsv1)- double(hsv4);
% dif1 = dif(:,:,1);
% dif2 = sum(sum(dif1));




% h = hsv(:,:,1);
% s = hsv(:,:,2);
% v = hsv(:,:,3);
% Num1 = size(find(h == 100),1);
% %%%%%%%%%%%%%%%%%%%%%%%
% 
% h1 = hsv1(:,:,1); 
% Num2 = size(find(h1 == 0.0),1);
% 
% 



