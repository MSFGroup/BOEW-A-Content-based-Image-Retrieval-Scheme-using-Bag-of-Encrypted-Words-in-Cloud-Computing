%written by Zhihua Xia xia_zhihua@163.com
clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ClusterNum = 100;
maxIter = 300;
blockHight = 50;
blockWidth = 50;
colorSpace = 'HSV_';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
strLocalHistogram       = ['BOEW_' colorSpace int2str(blockHight) '_' int2str(blockWidth) '_LocalHistogram.mat'];
strClusterCenter        = ['BOEW_' colorSpace int2str(blockHight) '_' int2str(blockWidth) '_ClusterCenters_ClusterNum=' int2str(ClusterNum) '_MaxIter=' int2str(maxIter) '.mat'];
strGlobalFeatre         = ['BOEW_' colorSpace int2str(blockHight) '_' int2str(blockWidth) '_GlobalFeature_ClusterNum=' int2str(ClusterNum) '_MaxIter=' int2str(maxIter) '.mat'];

%%%%%%%%%%%%%%%%%%%%%
%%load local histograms and cluster centers
dataLocalHistograms     = load(strLocalHistogram);
localHistograms         = dataLocalHistograms.localHistograms;
dataClusterCenter       = load(strClusterCenter);
clusterCenters          = dataClusterCenter.C;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% All the local histograms are stored in a cell
imgNum          = size(localHistograms,1);%% it is 1491 for Inria
featureLen      = size(clusterCenters,1);%% 
globalFeatures  = zeros(imgNum,featureLen);
fileNames       = dataLocalHistograms.fileNames;
clear dataLocalHistograms dataClusterCenter;
tic;
for imgIdx = 1:imgNum
    %%% For one image, computer the distance of each local histogram to each cluster center.
    similarDistances = pdist2(localHistograms{imgIdx},clusterCenters,'cityblock');
    %%% Find the index of smallest elements in each row.    
    [minElements,idx]        = min(similarDistances,[],2);
    %%% The histogram of idx is the Global feature of the image
    bins                     = 0.5:1:ClusterNum+0.5;
    hist                     = histogram(idx,bins);
    
    globalFeatures(imgIdx,:) = hist.Values;    
end
time = toc;
save(strGlobalFeatre','globalFeatures','featureLen','fileNames','time', '-v7.3');



















