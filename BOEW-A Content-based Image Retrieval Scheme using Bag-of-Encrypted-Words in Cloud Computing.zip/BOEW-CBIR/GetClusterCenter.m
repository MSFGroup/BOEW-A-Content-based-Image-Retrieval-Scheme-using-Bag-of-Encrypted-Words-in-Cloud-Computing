%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ClusterNum = 200;
maxIter = 300;
blockHight = 50;
blockWidth = 50;
colorSpace = 'HSV_';
selectStep = 4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
strSavePath = ['BOEW_' colorSpace int2str(blockHight) '_' int2str(blockWidth) '_ClusterCenters_' 'ClusterNum=' int2str(ClusterNum) '_MaxIter=' int2str(maxIter) '_selectStep=' '.mat']
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%clear all;
% clc;
% tic 
% data = load(['BOEW_' colorSpace int2str(blockHight) '_' int2str(blockWidth) '_LocalHistogram.mat']); 
% timeLoad = toc
% allLocalHistograms = cell2mat(data.localHistograms);
% save(['BOEW_' colorSpace int2str(blockHight) '_' int2str(blockWidth) '_LocalHistogram_pure.mat'],'allLocalHistograms','-v7.3');
% timeCombin = toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
data = load(['BOEW_' colorSpace int2str(blockHight) '_' int2str(blockWidth) '_LocalHistogram_pure.mat']);
allLocalHistograms = data.allLocalHistograms;
[idx,C,sumd,D] = kmeans(allLocalHistograms,ClusterNum,'distance','cityblock','MaxIter',maxIter);
time = toc
save(strSavePath,'C','idx','sumd','D','maxIter','time', '-v7.3');
