%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%written by Zhihua Xia at SKKU, June 14, 2017, xia_zhihua@163.com
clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
strSavaPathOfInriaImageClassInfo= 'InriaImageClassInfo.mat';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
imageNum = 1491;
classNum = 500;
imgClass = cell(classNum,1);
%ImgNames            = cell(imageNum,1);
imagefolder = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dirOutput = dir(fullfile(imagefolder,'*.jpg'));
imgNames={dirOutput.name};
%save(strSavaPathOfInriaImageClassInfo,'imgNames');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for classIdx = 1:classNum
    imageIdx = 1000 + classIdx - 1;
    imagePath = strcat(imagefolder,int2str(imageIdx),'*.jpg');
    dirOutput = dir(fullfile(imagePath));
    imgClass{classIdx} = {dirOutput.name};
end
save(strSavaPathOfInriaImageClassInfo,'imgClass','imgNames');