%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Written by Zhihua Xia, xia_zhihua@163.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%built a cell with 1491 elements. each element saves all the local
%histogram of an image.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% blockHight and block width could be different, but here we set them the
%%% same.
blockHight = 50;
blockWidth = 50;
colorSpace = 'HSV_';

strSavaPathofLocalBlockHistogram = ['BOEW_' colorSpace int2str(blockHight) '_' int2str(blockWidth) '_LocalHistogram.mat'];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
imageNum = 1491;
localHistograms = cell(imageNum,1);
imagefolder = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\';
dirOutput = dir(fullfile(imagefolder,'*.jpg'));
fileNames={dirOutput.name};
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(imagefolder,fileNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [h,s,v]=rgb2hsv(image);
    H = int8(floor(h * 100));
    S = int8(floor(s * 100));
    V = int8(floor(v * 100));    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [imgHight,imgWidth] = size(H);
    blkNumH = floor(imgHight/blockHight);
    blkNumW = floor(imgWidth/blockWidth);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    localHistofOneImg = zeros(blkNumH * blkNumW, 303);
    
    blkIdx = 1;  
    for blkIdxH = 1:blkNumH
        for blkIdxW = 1:blkNumW
            
                      
            localHistH = zeros(1,101);
            localHistS = zeros(1,101);
            localHistV = zeros(1,101);
           
            imgBlk_H = H(((blkIdxH-1)*blockHight+1):(blkIdxH*blockHight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth));
            imgBlk_S = S(((blkIdxH-1)*blockHight+1):(blkIdxH*blockHight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth));
            imgBlk_V = V(((blkIdxH-1)*blockHight+1):(blkIdxH*blockHight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth));
            
            for pixelIdx_H = 1:blockHight
                for pixelIdx_W = 1:blockWidth
                    localHistH(imgBlk_H(pixelIdx_H,pixelIdx_W) +1) = localHistH(imgBlk_H(pixelIdx_H,pixelIdx_W) +1) + 1;
                    localHistS(imgBlk_S(pixelIdx_H,pixelIdx_W) +1) = localHistS(imgBlk_S(pixelIdx_H,pixelIdx_W) +1) + 1;
                    localHistV(imgBlk_V(pixelIdx_H,pixelIdx_W) +1) = localHistV(imgBlk_V(pixelIdx_H,pixelIdx_W) +1) + 1;
                end
            end
            localHistofOneImg(blkIdx,:) = [localHistH localHistS localHistV];
            blkIdx = blkIdx +1;
            
        end
    end
    localHistograms{imgIdx} = localHistofOneImg;
     
end
time = toc;

% Construct a questdlg with three options
IsSave = questdlg('Would you like Save? Be carefull to your file name', ...
	'Dessert Menu', ...
	'Yes Save','No not Save','No not Save');
% Handle response
switch IsSave
    case 'Yes Save'
        save(strSavaPathofLocalBlockHistogram,'localHistograms','fileNames','time','blockHight','blockWidth', '-v7.3');
         disp('file is saved');
    case 'No not Save'
        disp('file is not saved');
        
end
%