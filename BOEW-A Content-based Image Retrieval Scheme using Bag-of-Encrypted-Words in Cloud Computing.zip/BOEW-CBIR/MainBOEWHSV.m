clear all;
clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
strImgFolder = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHight              = 50;
blockWidth              = 50;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
localFeatureSelectStep  = 4;  %% Candidates 2, 8 
ClusterNum              = 100;%% Candidates 50, 100, 200, 300, 1000
maxIter                 = 300;%% Candidates 100
clusterDistanceType     = 'cityblock';%% enclidean
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
searchDistanceType       = 'cityblock';%% enclidean
strInriaDataFileSavePath = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\eval_holidays\';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







[imgNames,localHistograms,runningTime] = GenLocalBlockHistogramHSV(strImgFolder,blockHight,blockWidth);