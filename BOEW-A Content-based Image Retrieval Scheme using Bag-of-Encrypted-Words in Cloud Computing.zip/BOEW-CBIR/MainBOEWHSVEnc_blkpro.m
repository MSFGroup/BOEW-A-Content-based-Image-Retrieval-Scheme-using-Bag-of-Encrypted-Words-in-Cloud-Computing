clear;
clc;
strImgFolder = 'E:\MyNetDisk\INRIA HOLIDAYS DATASET\Images\';
dirOutput = dir(fullfile(strImgFolder,'*.jpg'));
imgNames={dirOutput.name};
imageNum = size(imgNames,2); 
keyH = 1; keyS = 2; keyV = 3;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 10;
blockWidth = 10;
%imageNum =1;
i = 1;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    %HSVImgEnc = int8(floor(HSVImgEnc * 100));
    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blkNum = blkNumH*blkNumW;
    blks = cell(blkNum,1);
    s = RandStream('mt19937ar','Seed',imgIdx);
    rp = randperm(s,blkNum);    
    blkIdxInEncdImg = 1;  
    for blkIdxH_E = 1:blkNumH
        for blkIdxW_E = 1:blkNumW
        blkIdxInOriginalImg = rp(blkIdxInEncdImg);
        blkIdxH_O = uint32(floor((blkIdxInOriginalImg-1)/blkNumW) + 1);
        blkIdxW_O = uint32(mod(blkIdxInOriginalImg - 1,blkNumW)+1);
        HSVImgEnc(((blkIdxH_E-1)*blockHeight+1):(blkIdxH_E*blockHeight),((blkIdxW_E-1)*blockWidth+1):(blkIdxW_E*blockWidth),:) = ...
            HSVImgEnc(((blkIdxH_O-1)*blockHeight+1):(blkIdxH_O*blockHeight),((blkIdxW_O-1)*blockWidth+1):(blkIdxW_O*blockWidth),:);
        blkIdxInEncdImg = blkIdxInEncdImg + 1;
        end
    end
     
   [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blksize = blockHeight * blockWidth;
    %blkNum = blkNumH*blkNumW;
    blkIdx = 1;             
    for blkIdxH = 1:blkNumH
        for blkIdxW = 1:blkNumW
            ss1 = uint32(log2(blkIdx) + 1);
            ss2 = bitshift(imgIdx,ss1);
            ss3 = bitor(ss2,blkIdx);
            s = RandStream('mt19937ar','Seed',ss3);
            rp = randperm(s,blksize); 
            rp = reshape(rp,blockHeight,blockWidth); 
            
            blkH = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1);
            blkS = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2);
            blkV = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3);            
            blkIdx = blkIdx + 1;
         end
    end
    funH=@(blk) blkH(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1)=blkproc(blkH,[blockHeight blockWidth],funH);%�ֿ鴦��
    funS=@(blk) blkS(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2) = blkproc(blkS,[blockHeight blockWidth],funS);
    funV=@(blk) blkV(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3) =blkproc(blkV,[blockHeight blockWidth],funV);

    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    sH = RandStream('mt19937ar','Seed',keyH);
    sS = RandStream('mt19937ar','Seed',keyS);
    sV = RandStream('mt19937ar','Seed',keyV);
    rpH = uint8(randperm(sH,101));
    rpS = uint8(randperm(sS,101));
    rpV = uint8(randperm(sV,101));
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    H = HSVImgEnc(:,:,1);
    S = HSVImgEnc(:,:,2);
    V = HSVImgEnc(:,:,3);
     for pixelValue =0:100
        idx=find(HSVImgEnc(:,:,1) == pixelValue);
        H(idx) = rpH(pixelValue+1);

        idx=find(HSVImgEnc(:,:,2) == pixelValue);
        S(idx) = rpS(pixelValue+1);
        
        idx=find(HSVImgEnc(:,:,3) == pixelValue);
        V(idx) = rpV(pixelValue+1);  
     end   
    HSVImgEnc(:,:,1) = H;
    HSVImgEnc(:,:,2) = S;
    HSVImgEnc(:,:,3) = V;
    HSVImgEnc = double(HSVImgEnc)/100.0;
   % HSVImgEnc = double(HSVImgEnc)/100.0;
   % HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end

time(i) = toc;
i = i +1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 15;
blockWidth = 15;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blkNum = blkNumH*blkNumW;
    blks = cell(blkNum,1);
    s = RandStream('mt19937ar','Seed',imgIdx);
    rp = randperm(s,blkNum);    
    blkIdxInEncdImg = 1;  
    for blkIdxH_E = 1:blkNumH
        for blkIdxW_E = 1:blkNumW
        blkIdxInOriginalImg = rp(blkIdxInEncdImg);
        blkIdxH_O = uint32(floor((blkIdxInOriginalImg-1)/blkNumW) + 1);
        blkIdxW_O = uint32(mod(blkIdxInOriginalImg - 1,blkNumW)+1);
        HSVImgEnc(((blkIdxH_E-1)*blockHeight+1):(blkIdxH_E*blockHeight),((blkIdxW_E-1)*blockWidth+1):(blkIdxW_E*blockWidth),:) = ...
            HSVImgEnc(((blkIdxH_O-1)*blockHeight+1):(blkIdxH_O*blockHeight),((blkIdxW_O-1)*blockWidth+1):(blkIdxW_O*blockWidth),:);
        blkIdxInEncdImg = blkIdxInEncdImg + 1;
        end
    end
     
   [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blksize = blockHeight * blockWidth;
    %blkNum = blkNumH*blkNumW;
    blkIdx = 1;             
    for blkIdxH = 1:blkNumH
        for blkIdxW = 1:blkNumW
            ss1 = uint32(log2(blkIdx) + 1);
            ss2 = bitshift(imgIdx,ss1);
            ss3 = bitor(ss2,blkIdx);
            s = RandStream('mt19937ar','Seed',ss3);
            rp = randperm(s,blksize); 
            rp = reshape(rp,blockHeight,blockWidth); 
            
            blkH = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1);
            blkS = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2);
            blkV = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3);            
            blkIdx = blkIdx + 1;
         end
    end
    funH=@(blk) blkH(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1)=blkproc(blkH,[blockHeight blockWidth],funH);%�ֿ鴦��
    funS=@(blk) blkS(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2) = blkproc(blkS,[blockHeight blockWidth],funS);
    funV=@(blk) blkV(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3) =blkproc(blkV,[blockHeight blockWidth],funV);

    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    sH = RandStream('mt19937ar','Seed',keyH);
    sS = RandStream('mt19937ar','Seed',keyS);
    sV = RandStream('mt19937ar','Seed',keyV);
    rpH = uint8(randperm(sH,101));
    rpS = uint8(randperm(sS,101));
    rpV = uint8(randperm(sV,101));
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    H = HSVImgEnc(:,:,1);
    S = HSVImgEnc(:,:,2);
    V = HSVImgEnc(:,:,3);
     for pixelValue =0:100
        idx=find(HSVImgEnc(:,:,1) == pixelValue);
        H(idx) = rpH(pixelValue+1);

        idx=find(HSVImgEnc(:,:,2) == pixelValue);
        S(idx) = rpS(pixelValue+1);
        
        idx=find(HSVImgEnc(:,:,3) == pixelValue);
        V(idx) = rpV(pixelValue+1);  
     end   
    HSVImgEnc(:,:,1) = H;
    HSVImgEnc(:,:,2) = S;
    HSVImgEnc(:,:,3) = V;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc;
i = i +1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 20;
blockWidth = 20;
tic
for imgIdx = 1:imageNum
   disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blkNum = blkNumH*blkNumW;
    blks = cell(blkNum,1);
    s = RandStream('mt19937ar','Seed',imgIdx);
    rp = randperm(s,blkNum);    
    blkIdxInEncdImg = 1;  
    for blkIdxH_E = 1:blkNumH
        for blkIdxW_E = 1:blkNumW
        blkIdxInOriginalImg = rp(blkIdxInEncdImg);
        blkIdxH_O = uint32(floor((blkIdxInOriginalImg-1)/blkNumW) + 1);
        blkIdxW_O = uint32(mod(blkIdxInOriginalImg - 1,blkNumW)+1);
        HSVImgEnc(((blkIdxH_E-1)*blockHeight+1):(blkIdxH_E*blockHeight),((blkIdxW_E-1)*blockWidth+1):(blkIdxW_E*blockWidth),:) = ...
            HSVImgEnc(((blkIdxH_O-1)*blockHeight+1):(blkIdxH_O*blockHeight),((blkIdxW_O-1)*blockWidth+1):(blkIdxW_O*blockWidth),:);
        blkIdxInEncdImg = blkIdxInEncdImg + 1;
        end
    end
     
   [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blksize = blockHeight * blockWidth;
    %blkNum = blkNumH*blkNumW;
    blkIdx = 1;             
    for blkIdxH = 1:blkNumH
        for blkIdxW = 1:blkNumW
            ss1 = uint32(log2(blkIdx) + 1);
            ss2 = bitshift(imgIdx,ss1);
            ss3 = bitor(ss2,blkIdx);
            s = RandStream('mt19937ar','Seed',ss3);
            rp = randperm(s,blksize); 
            rp = reshape(rp,blockHeight,blockWidth); 
            
            blkH = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1);
            blkS = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2);
            blkV = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3);            
            blkIdx = blkIdx + 1;
         end
    end
    funH=@(blk) blkH(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1)=blkproc(blkH,[blockHeight blockWidth],funH);%�ֿ鴦��
    funS=@(blk) blkS(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2) = blkproc(blkS,[blockHeight blockWidth],funS);
    funV=@(blk) blkV(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3) =blkproc(blkV,[blockHeight blockWidth],funV);

    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    sH = RandStream('mt19937ar','Seed',keyH);
    sS = RandStream('mt19937ar','Seed',keyS);
    sV = RandStream('mt19937ar','Seed',keyV);
    rpH = uint8(randperm(sH,101));
    rpS = uint8(randperm(sS,101));
    rpV = uint8(randperm(sV,101));
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    H = HSVImgEnc(:,:,1);
    S = HSVImgEnc(:,:,2);
    V = HSVImgEnc(:,:,3);
     for pixelValue =0:100
        idx=find(HSVImgEnc(:,:,1) == pixelValue);
        H(idx) = rpH(pixelValue+1);

        idx=find(HSVImgEnc(:,:,2) == pixelValue);
        S(idx) = rpS(pixelValue+1);
        
        idx=find(HSVImgEnc(:,:,3) == pixelValue);
        V(idx) = rpV(pixelValue+1);  
     end   
    HSVImgEnc(:,:,1) = H;
    HSVImgEnc(:,:,2) = S;
    HSVImgEnc(:,:,3) = V;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc;
i = i +1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 25;
blockWidth = 25;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
   [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blkNum = blkNumH*blkNumW;
    blks = cell(blkNum,1);
    s = RandStream('mt19937ar','Seed',imgIdx);
    rp = randperm(s,blkNum);    
    blkIdxInEncdImg = 1;  
    for blkIdxH_E = 1:blkNumH
        for blkIdxW_E = 1:blkNumW
        blkIdxInOriginalImg = rp(blkIdxInEncdImg);
        blkIdxH_O = uint32(floor((blkIdxInOriginalImg-1)/blkNumW) + 1);
        blkIdxW_O = uint32(mod(blkIdxInOriginalImg - 1,blkNumW)+1);
        HSVImgEnc(((blkIdxH_E-1)*blockHeight+1):(blkIdxH_E*blockHeight),((blkIdxW_E-1)*blockWidth+1):(blkIdxW_E*blockWidth),:) = ...
            HSVImgEnc(((blkIdxH_O-1)*blockHeight+1):(blkIdxH_O*blockHeight),((blkIdxW_O-1)*blockWidth+1):(blkIdxW_O*blockWidth),:);
        blkIdxInEncdImg = blkIdxInEncdImg + 1;
        end
    end
     
   [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blksize = blockHeight * blockWidth;
    %blkNum = blkNumH*blkNumW;
    blkIdx = 1;             
    for blkIdxH = 1:blkNumH
        for blkIdxW = 1:blkNumW
            ss1 = uint32(log2(blkIdx) + 1);
            ss2 = bitshift(imgIdx,ss1);
            ss3 = bitor(ss2,blkIdx);
            s = RandStream('mt19937ar','Seed',ss3);
            rp = randperm(s,blksize); 
            rp = reshape(rp,blockHeight,blockWidth); 
            
            blkH = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1);
            blkS = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2);
            blkV = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3);            
            blkIdx = blkIdx + 1;
         end
    end
    funH=@(blk) blkH(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1)=blkproc(blkH,[blockHeight blockWidth],funH);%�ֿ鴦��
    funS=@(blk) blkS(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2) = blkproc(blkS,[blockHeight blockWidth],funS);
    funV=@(blk) blkV(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3) =blkproc(blkV,[blockHeight blockWidth],funV);

    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    sH = RandStream('mt19937ar','Seed',keyH);
    sS = RandStream('mt19937ar','Seed',keyS);
    sV = RandStream('mt19937ar','Seed',keyV);
    rpH = uint8(randperm(sH,101));
    rpS = uint8(randperm(sS,101));
    rpV = uint8(randperm(sV,101));
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    H = HSVImgEnc(:,:,1);
    S = HSVImgEnc(:,:,2);
    V = HSVImgEnc(:,:,3);
     for pixelValue =0:100
        idx=find(HSVImgEnc(:,:,1) == pixelValue);
        H(idx) = rpH(pixelValue+1);

        idx=find(HSVImgEnc(:,:,2) == pixelValue);
        S(idx) = rpS(pixelValue+1);
        
        idx=find(HSVImgEnc(:,:,3) == pixelValue);
        V(idx) = rpV(pixelValue+1);  
     end   
    HSVImgEnc(:,:,1) = H;
    HSVImgEnc(:,:,2) = S;
    HSVImgEnc(:,:,3) = V;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc;
i = i +1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 50;
blockWidth = 50;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blkNum = blkNumH*blkNumW;
    blks = cell(blkNum,1);
    s = RandStream('mt19937ar','Seed',imgIdx);
    rp = randperm(s,blkNum);    
    blkIdxInEncdImg = 1;  
    for blkIdxH_E = 1:blkNumH
        for blkIdxW_E = 1:blkNumW
        blkIdxInOriginalImg = rp(blkIdxInEncdImg);
        blkIdxH_O = uint32(floor((blkIdxInOriginalImg-1)/blkNumW) + 1);
        blkIdxW_O = uint32(mod(blkIdxInOriginalImg - 1,blkNumW)+1);
        HSVImgEnc(((blkIdxH_E-1)*blockHeight+1):(blkIdxH_E*blockHeight),((blkIdxW_E-1)*blockWidth+1):(blkIdxW_E*blockWidth),:) = ...
            HSVImgEnc(((blkIdxH_O-1)*blockHeight+1):(blkIdxH_O*blockHeight),((blkIdxW_O-1)*blockWidth+1):(blkIdxW_O*blockWidth),:);
        blkIdxInEncdImg = blkIdxInEncdImg + 1;
        end
    end
     
   [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blksize = blockHeight * blockWidth;
    %blkNum = blkNumH*blkNumW;
    blkIdx = 1;             
    for blkIdxH = 1:blkNumH
        for blkIdxW = 1:blkNumW
            ss1 = uint32(log2(blkIdx) + 1);
            ss2 = bitshift(imgIdx,ss1);
            ss3 = bitor(ss2,blkIdx);
            s = RandStream('mt19937ar','Seed',ss3);
            rp = randperm(s,blksize); 
            rp = reshape(rp,blockHeight,blockWidth); 
            
            blkH = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1);
            blkS = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2);
            blkV = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3);            
            blkIdx = blkIdx + 1;
         end
    end
    funH=@(blk) blkH(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1)=blkproc(blkH,[blockHeight blockWidth],funH);%�ֿ鴦��
    funS=@(blk) blkS(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2) = blkproc(blkS,[blockHeight blockWidth],funS);
    funV=@(blk) blkV(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3) =blkproc(blkV,[blockHeight blockWidth],funV);

    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    sH = RandStream('mt19937ar','Seed',keyH);
    sS = RandStream('mt19937ar','Seed',keyS);
    sV = RandStream('mt19937ar','Seed',keyV);
    rpH = uint8(randperm(sH,101));
    rpS = uint8(randperm(sS,101));
    rpV = uint8(randperm(sV,101));
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    H = HSVImgEnc(:,:,1);
    S = HSVImgEnc(:,:,2);
    V = HSVImgEnc(:,:,3);
     for pixelValue =0:100
        idx=find(HSVImgEnc(:,:,1) == pixelValue);
        H(idx) = rpH(pixelValue+1);

        idx=find(HSVImgEnc(:,:,2) == pixelValue);
        S(idx) = rpS(pixelValue+1);
        
        idx=find(HSVImgEnc(:,:,3) == pixelValue);
        V(idx) = rpV(pixelValue+1);  
     end   
    HSVImgEnc(:,:,1) = H;
    HSVImgEnc(:,:,2) = S;
    HSVImgEnc(:,:,3) = V;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc;
i = i +1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 100;
blockWidth = 100;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blkNum = blkNumH*blkNumW;
    blks = cell(blkNum,1);
    s = RandStream('mt19937ar','Seed',imgIdx);
    rp = randperm(s,blkNum);    
    blkIdxInEncdImg = 1;  
    for blkIdxH_E = 1:blkNumH
        for blkIdxW_E = 1:blkNumW
        blkIdxInOriginalImg = rp(blkIdxInEncdImg);
        blkIdxH_O = uint32(floor((blkIdxInOriginalImg-1)/blkNumW) + 1);
        blkIdxW_O = uint32(mod(blkIdxInOriginalImg - 1,blkNumW)+1);
        HSVImgEnc(((blkIdxH_E-1)*blockHeight+1):(blkIdxH_E*blockHeight),((blkIdxW_E-1)*blockWidth+1):(blkIdxW_E*blockWidth),:) = ...
            HSVImgEnc(((blkIdxH_O-1)*blockHeight+1):(blkIdxH_O*blockHeight),((blkIdxW_O-1)*blockWidth+1):(blkIdxW_O*blockWidth),:);
        blkIdxInEncdImg = blkIdxInEncdImg + 1;
        end
    end
     
   [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blksize = blockHeight * blockWidth;
    %blkNum = blkNumH*blkNumW;
    blkIdx = 1;             
    for blkIdxH = 1:blkNumH
        for blkIdxW = 1:blkNumW
            ss1 = uint32(log2(blkIdx) + 1);
            ss2 = bitshift(imgIdx,ss1);
            ss3 = bitor(ss2,blkIdx);
            s = RandStream('mt19937ar','Seed',ss3);
            rp = randperm(s,blksize); 
            rp = reshape(rp,blockHeight,blockWidth); 
            
            blkH = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1);
            blkS = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2);
            blkV = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3);            
            blkIdx = blkIdx + 1;
         end
    end
    funH=@(blk) blkH(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1)=blkproc(blkH,[blockHeight blockWidth],funH);%�ֿ鴦��
    funS=@(blk) blkS(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2) = blkproc(blkS,[blockHeight blockWidth],funS);
    funV=@(blk) blkV(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3) =blkproc(blkV,[blockHeight blockWidth],funV);

    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    sH = RandStream('mt19937ar','Seed',keyH);
    sS = RandStream('mt19937ar','Seed',keyS);
    sV = RandStream('mt19937ar','Seed',keyV);
    rpH = uint8(randperm(sH,101));
    rpS = uint8(randperm(sS,101));
    rpV = uint8(randperm(sV,101));
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    H = HSVImgEnc(:,:,1);
    S = HSVImgEnc(:,:,2);
    V = HSVImgEnc(:,:,3);
     for pixelValue =0:100
        idx=find(HSVImgEnc(:,:,1) == pixelValue);
        H(idx) = rpH(pixelValue+1);

        idx=find(HSVImgEnc(:,:,2) == pixelValue);
        S(idx) = rpS(pixelValue+1);
        
        idx=find(HSVImgEnc(:,:,3) == pixelValue);
        V(idx) = rpV(pixelValue+1);  
     end   
    HSVImgEnc(:,:,1) = H;
    HSVImgEnc(:,:,2) = S;
    HSVImgEnc(:,:,3) = V;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc;
i = i +1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
blockHeight = 200;
blockWidth = 200;
tic
for imgIdx = 1:imageNum
    disp(imgIdx);
    imagePath = strcat(strImgFolder,imgNames{imgIdx});
    image = imread(imagePath);
    %%%%%%%%%%%%%%%%
    HSVImgEnc = rgb2hsv(image);
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blkNum = blkNumH*blkNumW;
    blks = cell(blkNum,1);
    s = RandStream('mt19937ar','Seed',imgIdx);
    rp = randperm(s,blkNum);    
    blkIdxInEncdImg = 1;  
    for blkIdxH_E = 1:blkNumH
        for blkIdxW_E = 1:blkNumW
        blkIdxInOriginalImg = rp(blkIdxInEncdImg);
        blkIdxH_O = uint32(floor((blkIdxInOriginalImg-1)/blkNumW) + 1);
        blkIdxW_O = uint32(mod(blkIdxInOriginalImg - 1,blkNumW)+1);
        HSVImgEnc(((blkIdxH_E-1)*blockHeight+1):(blkIdxH_E*blockHeight),((blkIdxW_E-1)*blockWidth+1):(blkIdxW_E*blockWidth),:) = ...
            HSVImgEnc(((blkIdxH_O-1)*blockHeight+1):(blkIdxH_O*blockHeight),((blkIdxW_O-1)*blockWidth+1):(blkIdxW_O*blockWidth),:);
        blkIdxInEncdImg = blkIdxInEncdImg + 1;
        end
    end
     
   [imgHeight,imgWidth,~] = size(HSVImgEnc);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blksize = blockHeight * blockWidth;
    %blkNum = blkNumH*blkNumW;
    blkIdx = 1;             
    for blkIdxH = 1:blkNumH
        for blkIdxW = 1:blkNumW
            ss1 = uint32(log2(blkIdx) + 1);
            ss2 = bitshift(imgIdx,ss1);
            ss3 = bitor(ss2,blkIdx);
            s = RandStream('mt19937ar','Seed',ss3);
            rp = randperm(s,blksize); 
            rp = reshape(rp,blockHeight,blockWidth); 
            
            blkH = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1);
            blkS = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2);
            blkV = HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3);            
            blkIdx = blkIdx + 1;
         end
    end
    funH=@(blk) blkH(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),1)=blkproc(blkH,[blockHeight blockWidth],funH);%�ֿ鴦��
    funS=@(blk) blkS(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),2) = blkproc(blkS,[blockHeight blockWidth],funS);
    funV=@(blk) blkV(rp);
    HSVImgEnc(((blkIdxH-1)*blockHeight+1):(blkIdxH*blockHeight),((blkIdxW-1)*blockWidth+1):(blkIdxW*blockWidth),3) =blkproc(blkV,[blockHeight blockWidth],funV);

    [imgHeight,imgWidth,~] = size(HSVImgEnc);
    sH = RandStream('mt19937ar','Seed',keyH);
    sS = RandStream('mt19937ar','Seed',keyS);
    sV = RandStream('mt19937ar','Seed',keyV);
    rpH = uint8(randperm(sH,101));
    rpS = uint8(randperm(sS,101));
    rpV = uint8(randperm(sV,101));
    HSVImgEnc = int8(floor(HSVImgEnc * 100));
    H = HSVImgEnc(:,:,1);
    S = HSVImgEnc(:,:,2);
    V = HSVImgEnc(:,:,3);
     for pixelValue =0:100
        idx=find(HSVImgEnc(:,:,1) == pixelValue);
        H(idx) = rpH(pixelValue+1);

        idx=find(HSVImgEnc(:,:,2) == pixelValue);
        S(idx) = rpS(pixelValue+1);
        
        idx=find(HSVImgEnc(:,:,3) == pixelValue);
        V(idx) = rpV(pixelValue+1);  
     end   
    HSVImgEnc(:,:,1) = H;
    HSVImgEnc(:,:,2) = S;
    HSVImgEnc(:,:,3) = V;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = double(HSVImgEnc)/100.0;
    HSVImgEnc = hsv2rgb(HSVImgEnc);
   % imshow(HSVImgEnc);
end
time(i) = toc;
i = i +1;

save('time.mat','time', '-v7.3');