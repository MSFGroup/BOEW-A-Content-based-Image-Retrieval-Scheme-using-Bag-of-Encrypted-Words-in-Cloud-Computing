clear all;
clc;
data = load('BOEW_HSV_100_100_LocalHistogram');
imageNum = size(data.localHistograms,1);
for imgIdx = 1:imageNum
    localHistogramOfOneImage = data.localHistograms{imgIdx}
    blockNum = size(localHistogramOfOneImage,1);
    for blockIdx = 1:blockNum
        hh = figure(1);
        plot(localHistogramOfOneImage(blockIdx,:));
        pause(2)
        delete hh;
    end 
     
end
