    clc;
    clear;
I = imread('E:\MyNetDisk\INRIA HOLIDAYS DATASET\ExperimentData\EncImg-4\100301_1.png');

   hsv=rgb2hsv(I);
    hsv1=hsv(:,:,1);
  I1 = hsv2rgb(hsv)*255;
  dif = double(I) - I1;
  difsum = sum(sum(sum(dif)));
  dif1 = dif(:,:,1);