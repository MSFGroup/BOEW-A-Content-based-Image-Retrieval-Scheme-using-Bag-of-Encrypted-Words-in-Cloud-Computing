
% data = load('BOEW_HSV_100_100_LocalHistogram.mat');
% cent = load('BOEW_HSV_100_100_ClusterCenters_ClusterNum=100_MaxIter=300');
% globalFeatures = BOEWFunc_GenGlobalFeature(data.localHistograms,cent.C,'cityblock')

    [imgHeight,imgWidth,~] = size(Img);
    blkNumH = floor(imgHeight/blockHeight);
    blkNumW = floor(imgWidth/blockWidth);
    blksize = blockHeight * blockWidth;

            blkIdxInOriginalImg = rp(1);


            blkIdxH_O = uint32(floor((blkIdxInOriginalImg-1)/blkNumW) + 1);
            blkIdxW_O = uint32(mod(blkIdxInOriginalImg - 1,blkNumW)+1);
            Iblke = Img(((blkIdxH_O-1)*blockHeight+1):(blkIdxH_O*blockHeight),((blkIdxW_O-1)*blockWidth+1):(blkIdxW_O*blockWidth),:);
            Iblk = ImgEnc(((1-1)*blockHeight+1):(1*blockHeight),((1-1)*blockWidth+1):(1*blockWidth),:);

dif = Iblke-Iblk;